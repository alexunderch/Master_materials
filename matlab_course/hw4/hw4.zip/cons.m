function [c, ceq] = cons(x)
c = [x(1)^2 + x(2)^2 - 1; x(1)^2 - x(2) - 1];
ceq = [];
end
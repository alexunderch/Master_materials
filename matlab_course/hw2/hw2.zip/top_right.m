function N_ = top_right(N, n)
  N_ = N(1:n, end-n+1:end);
end
